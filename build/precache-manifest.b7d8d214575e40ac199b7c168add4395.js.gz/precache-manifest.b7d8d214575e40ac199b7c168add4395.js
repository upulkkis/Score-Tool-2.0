self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0ab86b0049132d8b4d40653bd04884f4",
    "url": "./index.html"
  },
  {
    "revision": "18d6584ca7dd1bb0b6b3",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "69f6e93f341a618145b8",
    "url": "./static/css/main.3c3d2d6d.chunk.css"
  },
  {
    "revision": "18d6584ca7dd1bb0b6b3",
    "url": "./static/js/2.97415a38.chunk.js"
  },
  {
    "revision": "69f6e93f341a618145b8",
    "url": "./static/js/main.217e4d1c.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);