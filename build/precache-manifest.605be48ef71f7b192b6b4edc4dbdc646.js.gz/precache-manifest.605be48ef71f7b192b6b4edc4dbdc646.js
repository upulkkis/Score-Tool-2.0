self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c9015d43f70b0cbf6f6e45cf8bd8d922",
    "url": "./index.html"
  },
  {
    "revision": "2e3713cf8348ff821630",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "0b84349528c3bf47b2df",
    "url": "./static/css/main.af535ee3.chunk.css"
  },
  {
    "revision": "2e3713cf8348ff821630",
    "url": "./static/js/2.9e573ad0.chunk.js"
  },
  {
    "revision": "0b84349528c3bf47b2df",
    "url": "./static/js/main.49cc05e1.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);