self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "af35271601f4ce978de1daa1c3a2f233",
    "url": "./index.html"
  },
  {
    "revision": "d783628490f9634357d5",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "a44d91049e41a98f31a7",
    "url": "./static/css/main.af535ee3.chunk.css"
  },
  {
    "revision": "d783628490f9634357d5",
    "url": "./static/js/2.c4685ee4.chunk.js"
  },
  {
    "revision": "a44d91049e41a98f31a7",
    "url": "./static/js/main.c2586878.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);