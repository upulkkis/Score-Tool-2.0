self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0f1e6ee54a43142958f9c5fb785de612",
    "url": "./index.html"
  },
  {
    "revision": "2c864ef81d6151a6114c",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "9ed95affcae4b7a0324a",
    "url": "./static/css/main.23508fd8.chunk.css"
  },
  {
    "revision": "2c864ef81d6151a6114c",
    "url": "./static/js/2.b46bf6be.chunk.js"
  },
  {
    "revision": "9ed95affcae4b7a0324a",
    "url": "./static/js/main.82fbc6c7.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);