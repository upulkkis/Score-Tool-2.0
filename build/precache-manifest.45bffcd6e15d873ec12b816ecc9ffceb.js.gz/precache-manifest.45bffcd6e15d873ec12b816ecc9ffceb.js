self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e9ecfa20fc33fa43411f5db79d6fca0b",
    "url": "./index.html"
  },
  {
    "revision": "6cc15f7b1c6fb76ada57",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "1b6278d6931bc2387cde",
    "url": "./static/css/main.e0f53daf.chunk.css"
  },
  {
    "revision": "6cc15f7b1c6fb76ada57",
    "url": "./static/js/2.d4995d98.chunk.js"
  },
  {
    "revision": "1b6278d6931bc2387cde",
    "url": "./static/js/main.aafad7a7.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);