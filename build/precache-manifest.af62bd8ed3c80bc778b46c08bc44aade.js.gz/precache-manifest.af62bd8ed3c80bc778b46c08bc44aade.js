self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "19637c18b4dca01e96e262cee48ca99d",
    "url": "./index.html"
  },
  {
    "revision": "b05ce993b550bf96925a",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "04ebc0cf40886fde1ea4",
    "url": "./static/css/main.3c3d2d6d.chunk.css"
  },
  {
    "revision": "b05ce993b550bf96925a",
    "url": "./static/js/2.37aa5003.chunk.js"
  },
  {
    "revision": "04ebc0cf40886fde1ea4",
    "url": "./static/js/main.bc7f7454.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);