self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c04ad2ebfca5786c79739813b4818c03",
    "url": "./index.html"
  },
  {
    "revision": "bf82848d4116439596d4",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "58b41f7e9224b2a36dd3",
    "url": "./static/css/main.12f791ad.chunk.css"
  },
  {
    "revision": "bf82848d4116439596d4",
    "url": "./static/js/2.8b3322ad.chunk.js"
  },
  {
    "revision": "58b41f7e9224b2a36dd3",
    "url": "./static/js/main.6ef4a234.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);