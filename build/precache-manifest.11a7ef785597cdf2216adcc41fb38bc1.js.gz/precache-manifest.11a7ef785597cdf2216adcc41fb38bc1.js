self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c93b20ff93b6d793f08bd77b88ea99e8",
    "url": "./index.html"
  },
  {
    "revision": "28c58a812987548b67ea",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "3d07b4d2254a7969c11e",
    "url": "./static/css/main.c2b41ee3.chunk.css"
  },
  {
    "revision": "28c58a812987548b67ea",
    "url": "./static/js/2.9d58db74.chunk.js"
  },
  {
    "revision": "3d07b4d2254a7969c11e",
    "url": "./static/js/main.f00fae82.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);