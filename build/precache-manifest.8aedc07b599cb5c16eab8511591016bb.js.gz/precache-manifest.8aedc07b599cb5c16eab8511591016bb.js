self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "436b72ba6a4f90d9d5b9568ba2e21a00",
    "url": "./index.html"
  },
  {
    "revision": "759baee8abd5e2fa03ee",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "c55e242118b4c03da65e",
    "url": "./static/css/main.23508fd8.chunk.css"
  },
  {
    "revision": "759baee8abd5e2fa03ee",
    "url": "./static/js/2.c0e1686a.chunk.js"
  },
  {
    "revision": "c55e242118b4c03da65e",
    "url": "./static/js/main.dae41d6a.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);