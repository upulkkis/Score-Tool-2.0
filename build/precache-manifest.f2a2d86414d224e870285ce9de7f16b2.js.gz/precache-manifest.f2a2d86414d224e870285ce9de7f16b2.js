self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a4e969c66238f0333f8cc6e84c6970e6",
    "url": "./index.html"
  },
  {
    "revision": "18d629810ad00801b2a3",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "797a46b6dc32cdb4d294",
    "url": "./static/css/main.49b45fe9.chunk.css"
  },
  {
    "revision": "18d629810ad00801b2a3",
    "url": "./static/js/2.c3cdea33.chunk.js"
  },
  {
    "revision": "797a46b6dc32cdb4d294",
    "url": "./static/js/main.dc1dd03a.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);