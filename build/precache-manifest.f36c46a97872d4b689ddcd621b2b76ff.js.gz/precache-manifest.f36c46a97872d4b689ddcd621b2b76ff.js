self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "050288a5b8f025fd4edf1dcdc7664f92",
    "url": "./index.html"
  },
  {
    "revision": "74c75ebb83cd92b317ac",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "761413da61946a7c41b7",
    "url": "./static/css/main.12f791ad.chunk.css"
  },
  {
    "revision": "74c75ebb83cd92b317ac",
    "url": "./static/js/2.97a60ca4.chunk.js"
  },
  {
    "revision": "761413da61946a7c41b7",
    "url": "./static/js/main.8406044a.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);