self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a78bb30c5d3518e906bdf1236465ee8f",
    "url": "./index.html"
  },
  {
    "revision": "55d1b31aabdbbf7ebf75",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "c4ea81a6b66bac7b684c",
    "url": "./static/css/main.23508fd8.chunk.css"
  },
  {
    "revision": "55d1b31aabdbbf7ebf75",
    "url": "./static/js/2.8c4599be.chunk.js"
  },
  {
    "revision": "c4ea81a6b66bac7b684c",
    "url": "./static/js/main.845a3712.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);