self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1c933dabd26c83bf3481a6b85e974817",
    "url": "./index.html"
  },
  {
    "revision": "6cc15f7b1c6fb76ada57",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "7f0809df9b00c0d6fe32",
    "url": "./static/css/main.e0f53daf.chunk.css"
  },
  {
    "revision": "6cc15f7b1c6fb76ada57",
    "url": "./static/js/2.d4995d98.chunk.js"
  },
  {
    "revision": "7f0809df9b00c0d6fe32",
    "url": "./static/js/main.f2edbd16.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);