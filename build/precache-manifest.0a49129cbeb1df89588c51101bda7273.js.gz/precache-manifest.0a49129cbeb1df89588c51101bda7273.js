self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8bccd6ce5fd7bf3b0e16301befe8d494",
    "url": "./index.html"
  },
  {
    "revision": "0bbaf40a1c4a24a26ecb",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "9d14b0e1912c2e297d94",
    "url": "./static/css/main.49b45fe9.chunk.css"
  },
  {
    "revision": "0bbaf40a1c4a24a26ecb",
    "url": "./static/js/2.48eaf689.chunk.js"
  },
  {
    "revision": "9d14b0e1912c2e297d94",
    "url": "./static/js/main.284524cd.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);