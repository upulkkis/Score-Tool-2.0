self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b19b4e20f1b6d509aeeee91a0eec4985",
    "url": "./index.html"
  },
  {
    "revision": "a22f7006c7f80e8c12c2",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "16a7db6e27da7fa44570",
    "url": "./static/css/main.23508fd8.chunk.css"
  },
  {
    "revision": "a22f7006c7f80e8c12c2",
    "url": "./static/js/2.98539670.chunk.js"
  },
  {
    "revision": "16a7db6e27da7fa44570",
    "url": "./static/js/main.bb80b237.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);