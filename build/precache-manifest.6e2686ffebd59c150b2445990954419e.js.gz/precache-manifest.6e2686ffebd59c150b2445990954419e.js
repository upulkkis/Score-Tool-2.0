self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cf3f924086bf6ab699da7a1054dcdbd1",
    "url": "./index.html"
  },
  {
    "revision": "2411aa78902684b665a7",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "6689800ada621ef52f71",
    "url": "./static/css/main.49b45fe9.chunk.css"
  },
  {
    "revision": "2411aa78902684b665a7",
    "url": "./static/js/2.1d396e8b.chunk.js"
  },
  {
    "revision": "6689800ada621ef52f71",
    "url": "./static/js/main.82d6ae32.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);