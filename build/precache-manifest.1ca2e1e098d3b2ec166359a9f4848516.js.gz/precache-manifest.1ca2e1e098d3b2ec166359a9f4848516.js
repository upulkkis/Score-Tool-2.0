self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b393eaa398328e9a21e90acfd48d5e2e",
    "url": "./index.html"
  },
  {
    "revision": "63edc9caed1743e24fd6",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "1bbbe1efb7e9e55b12d3",
    "url": "./static/css/main.12f791ad.chunk.css"
  },
  {
    "revision": "63edc9caed1743e24fd6",
    "url": "./static/js/2.e7fb9aba.chunk.js"
  },
  {
    "revision": "1bbbe1efb7e9e55b12d3",
    "url": "./static/js/main.08a57646.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);