self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "017a830c8251ac7f45db8090fcf4597b",
    "url": "./index.html"
  },
  {
    "revision": "08ea2c8fb607ae2d9210",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "82669a76fe623817c1b7",
    "url": "./static/css/main.c2b41ee3.chunk.css"
  },
  {
    "revision": "08ea2c8fb607ae2d9210",
    "url": "./static/js/2.5f2e7873.chunk.js"
  },
  {
    "revision": "82669a76fe623817c1b7",
    "url": "./static/js/main.70d31591.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);