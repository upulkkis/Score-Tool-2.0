self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1952292aad7a985fbc1568f818a636fd",
    "url": "./index.html"
  },
  {
    "revision": "302ac80ecb9fab92f236",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "362cea61af849f30917b",
    "url": "./static/css/main.23508fd8.chunk.css"
  },
  {
    "revision": "302ac80ecb9fab92f236",
    "url": "./static/js/2.16d078e8.chunk.js"
  },
  {
    "revision": "362cea61af849f30917b",
    "url": "./static/js/main.a5ffdbca.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);