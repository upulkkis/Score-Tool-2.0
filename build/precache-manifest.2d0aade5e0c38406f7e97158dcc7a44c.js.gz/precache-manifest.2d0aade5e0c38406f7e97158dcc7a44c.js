self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fb0353ce2b37e802233b99612e972e02",
    "url": "./index.html"
  },
  {
    "revision": "7bb3d53d5d41a4f70ead",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "d31e3a4238281d51bfef",
    "url": "./static/css/main.e0f53daf.chunk.css"
  },
  {
    "revision": "7bb3d53d5d41a4f70ead",
    "url": "./static/js/2.83002b9a.chunk.js"
  },
  {
    "revision": "d31e3a4238281d51bfef",
    "url": "./static/js/main.3fcd5a1e.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);