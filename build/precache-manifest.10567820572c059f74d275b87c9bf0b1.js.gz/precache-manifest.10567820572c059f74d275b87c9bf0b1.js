self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6b86e7818aaa11ff40cccce20e31fd84",
    "url": "./index.html"
  },
  {
    "revision": "0d326aa759206f10dc4b",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "5709399a9bf74f57ef05",
    "url": "./static/css/main.af535ee3.chunk.css"
  },
  {
    "revision": "0d326aa759206f10dc4b",
    "url": "./static/js/2.a9cd6c63.chunk.js"
  },
  {
    "revision": "5709399a9bf74f57ef05",
    "url": "./static/js/main.1d5f5189.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);