self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "81accb38d8e415bd0d479e8177c150ab",
    "url": "./index.html"
  },
  {
    "revision": "66dbf34ce0e421f18059",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "34697eae7131253a6289",
    "url": "./static/css/main.e0f53daf.chunk.css"
  },
  {
    "revision": "66dbf34ce0e421f18059",
    "url": "./static/js/2.8d5a6311.chunk.js"
  },
  {
    "revision": "34697eae7131253a6289",
    "url": "./static/js/main.f7ae0664.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);