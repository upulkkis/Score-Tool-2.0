self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "43fd086d06a46ce31afa9d8f22acee31",
    "url": "./index.html"
  },
  {
    "revision": "70167a4155067d3cf955",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "a8da7ec40c8c2ffd0505",
    "url": "./static/css/main.23508fd8.chunk.css"
  },
  {
    "revision": "70167a4155067d3cf955",
    "url": "./static/js/2.bacebd42.chunk.js"
  },
  {
    "revision": "a8da7ec40c8c2ffd0505",
    "url": "./static/js/main.f23cb32a.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);