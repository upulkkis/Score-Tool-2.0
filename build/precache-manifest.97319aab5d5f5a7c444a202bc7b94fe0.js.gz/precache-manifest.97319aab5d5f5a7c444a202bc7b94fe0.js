self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cfc1e2590fcb65a6ade15bb81b214287",
    "url": "./index.html"
  },
  {
    "revision": "48949d880655894f196d",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "ef7eef3025c8e1b13d28",
    "url": "./static/css/main.e0f53daf.chunk.css"
  },
  {
    "revision": "48949d880655894f196d",
    "url": "./static/js/2.00929550.chunk.js"
  },
  {
    "revision": "ef7eef3025c8e1b13d28",
    "url": "./static/js/main.527c659b.chunk.js"
  },
  {
    "revision": "a8c9ae6c458d70f8f09c",
    "url": "./static/js/runtime-main.bff35d10.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);