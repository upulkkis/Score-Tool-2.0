self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8cc57e4ac250da0acbce6e7df46f4c8c",
    "url": "./index.html"
  },
  {
    "revision": "0d326aa759206f10dc4b",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "0e412635c1e31c7b45f7",
    "url": "./static/css/main.af535ee3.chunk.css"
  },
  {
    "revision": "0d326aa759206f10dc4b",
    "url": "./static/js/2.a9cd6c63.chunk.js"
  },
  {
    "revision": "0e412635c1e31c7b45f7",
    "url": "./static/js/main.31f92afe.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);