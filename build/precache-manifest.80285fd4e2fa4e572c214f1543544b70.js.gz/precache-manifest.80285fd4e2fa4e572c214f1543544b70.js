self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ca68f2d2b7727cbd99bb55fce25c1a8f",
    "url": "./index.html"
  },
  {
    "revision": "2e3713cf8348ff821630",
    "url": "./static/css/2.ad1b8802.chunk.css"
  },
  {
    "revision": "82563dc9900594585146",
    "url": "./static/css/main.af535ee3.chunk.css"
  },
  {
    "revision": "2e3713cf8348ff821630",
    "url": "./static/js/2.9e573ad0.chunk.js"
  },
  {
    "revision": "82563dc9900594585146",
    "url": "./static/js/main.7e3bbdac.chunk.js"
  },
  {
    "revision": "db64c3c27e729bb54fa1",
    "url": "./static/js/runtime-main.c7d96805.js"
  },
  {
    "revision": "25c8c71ef01b79163f3b6ca1619d1790",
    "url": "./static/media/waves.25c8c71e.png"
  }
]);